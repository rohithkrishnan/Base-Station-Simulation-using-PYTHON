NOTE:
1) All the files and required modules are provided in the same directory so as to minimise 
the hassle of importing the file or module from another directory.
2) File sim_run.py is the main module which has the simulation code written on it.
The 2 modules eirp_calculator and path_loss, aid the main simulation in calculating 
path loss and EIRP at various stages in the simulation.